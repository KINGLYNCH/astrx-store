const crypto = require("crypto");

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function formatMoney(amount) {
  return `NGN ${Number(amount).toLocaleString("en-NG")}`;
}

function formatOrder(items) {
  return items
    .map(
      (item) =>
        `${item.name} | Color: ${item.color} | Qty: ${item.quantity} | Unit price: ${formatMoney(item.unitPrice)} | Line total: ${formatMoney(item.lineTotal)}`,
    )
    .join("\n");
}

module.exports = async function paystackWebhook(req, res) {
  if (req.method !== "POST") return res.status(405).send("Method not allowed");
  if (!process.env.PAYSTACK_SECRET_KEY || !process.env.RESEND_API_KEY || !process.env.STORE_EMAIL) {
    return res.status(500).send("Webhook email configuration is incomplete");
  }

  try {
    const rawBody = await readRawBody(req);
    const signature = crypto
      .createHmac("sha512", process.env.PAYSTACK_SECRET_KEY)
      .update(rawBody)
      .digest("hex");
    if (signature !== req.headers["x-paystack-signature"]) {
      return res.status(401).send("Invalid signature");
    }

    const event = JSON.parse(rawBody.toString("utf8"));
    if (event.event !== "charge.success") return res.status(200).send("Ignored");

    const transaction = event.data;
    const metadata = transaction.metadata || {};
    const items = typeof metadata.items === "string" ? JSON.parse(metadata.items) : metadata.items;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).send("Order metadata is missing");
    }

    const customerEmail = metadata.customer_email || transaction.customer?.email || "Not provided";
    const customerName = metadata.customer_name || "Not provided";
    const customerPhone = metadata.customer_phone || "Not provided";
    const deliveryAddress = metadata.delivery_address || "Not provided";
    const orderText = formatOrder(items);
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: process.env.RESEND_FROM_EMAIL || "ASTRX Store <onboarding@resend.dev>",
        to: [process.env.STORE_EMAIL],
        subject: `Paid ASTRX order - ${transaction.reference}`,
        text: `A new ASTRX order has been paid.\n\nCustomer name: ${customerName}\nEmail: ${customerEmail}\nPhone: ${customerPhone}\nDelivery address: ${deliveryAddress}\nPayment reference: ${transaction.reference}\nPayment amount: ${formatMoney(transaction.amount / 100)}\n\n${orderText}`,
      }),
    });
    if (!emailResponse.ok) return res.status(502).send("Order email failed");
    return res.status(200).send("Webhook processed");
  } catch (error) {
    return res.status(400).send(error.message || "Invalid webhook");
  }
};

module.exports.config = { api: { bodyParser: false } };
