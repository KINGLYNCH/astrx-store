const PRODUCTS = {
  bda: { name: "Better Days Ahead Tee", price: 45000, colors: ["White", "Black"] },
  pyl: { name: "Push Your Limit Tee", price: 45000, colors: ["Black", "White"] },
  dus: { name: "Do UR Sh>t Tee", price: 45000, colors: ["White", "Black"] },
  sassy: { name: "Sassy Girl Tee", price: 40000, colors: ["Black", "White"] },
  "sassy-girl-crop": { name: "Sassy Girl Female Crop Tee", price: 40000, colors: ["Black"] },
  "beanie-star": { name: "Star Badge Beanie", price: 22000, colors: ["Black"] },
  "beanie-script": { name: "ASTRX Script Beanie", price: 22000, colors: ["Black"] },
  skullcap: { name: "Star Badge Skull Cap", price: 22000, colors: ["Black"] },
};

function reply(res, status, body) {
  res.status(status).json(body);
}

module.exports = async function initializePayment(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return reply(res, 204, {});
  if (req.method !== "POST") return reply(res, 405, { error: "Method not allowed" });
  if (!process.env.PAYSTACK_SECRET_KEY) {
    return reply(res, 500, { error: "PAYSTACK_SECRET_KEY is not configured" });
  }

  const { email, name, phone, address, items } = req.body || {};
  if (!/^\S+@\S+\.\S+$/.test(email || "")) {
    return reply(res, 400, { error: "A valid customer email is required" });
  }
  if (!name?.trim() || !phone?.trim() || !address?.trim()) {
    return reply(res, 400, { error: "Name, phone number, and delivery address are required" });
  }
  if (name.trim().length > 100 || phone.trim().length > 40 || address.trim().length > 300) {
    return reply(res, 400, { error: "Customer details are too long" });
  }
  if (!Array.isArray(items) || items.length === 0) {
    return reply(res, 400, { error: "The cart is empty" });
  }

  try {
    const orderItems = items.map((item) => {
      const product = PRODUCTS[item.id];
      const quantity = Number(item.qty);
      if (!product || !product.colors.includes(item.color) || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) {
        throw new Error("Invalid cart item");
      }
      return {
        id: item.id,
        name: product.name,
        color: item.color,
        quantity,
        unitPrice: product.price,
        lineTotal: product.price * quantity,
      };
    });

    const amount = orderItems.reduce((sum, item) => sum + item.lineTotal, 0);
    const origin = process.env.SITE_URL || `https://${req.headers.host}`;
    const paystackResponse = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        amount: amount * 100,
        currency: "NGN",
        callback_url: `${origin}/?payment=complete`,
        metadata: {
          customer_name: name.trim(),
          customer_email: email,
          customer_phone: phone.trim(),
          delivery_address: address.trim(),
          items: orderItems,
          subtotal: amount,
        },
      }),
    });
    const result = await paystackResponse.json();
    if (!paystackResponse.ok || !result.status) {
      return reply(res, 502, { error: result.message || "Paystack could not initialize payment" });
    }
    return reply(res, 200, {
      authorization_url: result.data.authorization_url,
      reference: result.data.reference,
    });
  } catch (error) {
    return reply(res, 400, { error: error.message || "Invalid order" });
  }
};
