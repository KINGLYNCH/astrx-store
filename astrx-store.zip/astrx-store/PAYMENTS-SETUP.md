# ASTRX payments setup

The site uses Paystack Checkout in NGN. It runs as a small Node.js server, so you can host it on Render, Railway, a VPS, or any host that runs Node.js. The `api/` handlers are also kept available for serverless hosts.

## 1. Deploy the project

Use Node.js 18 or newer, then run:

```sh
npm start
```

Set the host's start command to `npm start`. The checkout request must be served from this Node server; opening `index.html` directly from the file system will not provide `/api/initialize-payment`.

## 2. Add environment variables

Add these variables in the hosting dashboard:

- `PAYSTACK_SECRET_KEY`: Paystack live secret key.
- `STORE_EMAIL`: email address that receives paid order notifications.
- `RESEND_API_KEY`: API key from Resend.
- `RESEND_FROM_EMAIL`: verified sender, for example `ASTRX Store <orders@yourdomain.com>`.
- `SITE_URL`: deployed site URL, for example `https://astrx-store.example.com`.

Never put `PAYSTACK_SECRET_KEY` in `index.html`.

## 3. Configure Resend

Verify your sending domain in Resend, then use an address on that domain for `RESEND_FROM_EMAIL`. The default Resend sender is only suitable for testing.

## 4. Configure Paystack webhooks

In the Paystack dashboard, set the webhook URL to:

`https://your-domain.com/api/paystack-webhook`

Paystack will sign the request, and the handler only emails orders after a valid `charge.success` event.

## 5. Test before going live

Use Paystack test keys and test cards first. Confirm that a successful test transaction reaches the webhook and sends an email. Change to live keys only after this works.
